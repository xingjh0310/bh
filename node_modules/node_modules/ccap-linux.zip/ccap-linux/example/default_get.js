var ccap = require('../');

var captcha = ccap();
var ary = captcha.get();

console.log(ary[0])
console.log(ary[1])
module.exports = require('./lib/hcap.js');







